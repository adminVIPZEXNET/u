"""Fast, dependency-free client for the official Rubika Bot API."""
from __future__ import annotations

import asyncio
import hashlib
import json
import mimetypes
import os
import secrets
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Callable

from ._token import resolve_token
from .api_methods import RubikaAPIMethods


_CYAN = "\033[96m"
_GREEN = "\033[92m"
_RED = "\033[91m"
_RESET = "\033[0m"
_BOLD = "\033[1m"


def _terminal_color(text: str, color: str) -> str:
    if os.environ.get("NO_COLOR") is not None or os.environ.get("TERM", "").lower() == "dumb":
        return text
    return f"{color}{text}{_RESET}"


class RubikaAPIError(RuntimeError):
    """Raised when the Rubika Bot API returns an error."""


class Event:
    """A normalized incoming update passed to event handlers."""

    def __init__(self, bot: "IRubix", raw: dict[str, Any]):
        self.bot = bot
        self.raw = raw
        self.update = raw
        self.type = raw.get("type", "")
        message = (
            raw.get("message")
            or raw.get("new_message")
            or raw.get("updated_message")
            or {}
        )
        self.message = message if isinstance(message, dict) else {}
        chat = self.message.get("chat") or {}
        self.chat_id = (
            raw.get("chat_id")
            or self.message.get("chat_id")
            or (chat.get("chat_id") if isinstance(chat, dict) else None)
        )
        self.message_id = self.message.get("message_id") or raw.get("message_id")
        self.text = self.message.get("text") or raw.get("text") or ""
        self.sender_id = (
            self.message.get("sender_id")
            or self.message.get("author_object_guid")
            or raw.get("sender_id")
            or raw.get("user_id")
        )
        aux_data = raw.get("aux_data") or {}
        self.button_id = raw.get("button_id") or raw.get("data") or (aux_data.get("button_id") if isinstance(aux_data, dict) else None)
        self.update_type = self.type
        parts = self.text.strip().split(maxsplit=1)
        raw_command = parts[0] if parts and parts[0].startswith("/") else ""
        self.command = raw_command[1:].split("@", 1)[0] if raw_command else ""
        self.args = parts[1] if len(parts) > 1 and raw_command else ""

    async def reply(self, text: str, **kwargs: Any):
        """Reply to the current message."""
        if not self.chat_id:
            raise RubikaAPIError("Chat ID was not found in this update.")
        if self.message_id:
            kwargs.setdefault("reply_to_message_id", self.message_id)
        return await self.bot.send_text(self.chat_id, text, **kwargs)


class IRubix(RubikaAPIMethods):
    """Async Rubika Bot API client. Uses only the Python standard library."""

    API_URL = "https://botapi.rubika.ir/v3"
    __version__ = "0.12.4"

    def __init__(
        self,
        token: str | None = None,
        *,
        timeout: float = 30,
        base_url: str | None = None,
    ):
        self.token = resolve_token(token, "Rubika")
        self.base_url = (base_url or self.API_URL).rstrip("/") + "/" + self.token
        self.timeout = timeout
        self._handlers: list[tuple[str, Any, Callable]] = []
        self._middlewares: list[Callable] = []
        self._plugins: list[Any] = []
        self._running = False

    def _request_sync(self, method: str, payload: dict | None = None):
        """Internal synchronous HTTP request; called in a worker thread."""
        url = self.base_url + "/" + method
        body = json.dumps(payload or {}, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            url,
            data=body,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": f"IRubix/{self.__version__}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                raw = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")
            raise RubikaAPIError(f"HTTP {exc.code}: {detail}") from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise RubikaAPIError(f"Connection error: {exc}") from exc

        try:
            result = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise RubikaAPIError("Rubika returned an invalid JSON response.") from exc

        if isinstance(result, dict):
            status = result.get("status")
            if status not in (None, "OK"):
                message = result.get("dev_message") or result.get("message") or status
                raise RubikaAPIError(str(message))
        return result

    async def request(self, method: str, input: dict | None = None):
        """Call any official Bot API method asynchronously."""
        if not method or "/" in method:
            raise ValueError("Invalid API method name.")
        return await asyncio.to_thread(self._request_sync, method, input)

    async def get_me(self):
        """Return bot information using getMe."""
        return await self.request("getMe")

    async def get_chat(self, chat_id: str):
        """Return information about a chat using getChat."""
        return await self.request("getChat", {"chat_id": chat_id})

    async def get_file(self, file_id: str):
        """Get a file download URL using getFile."""
        return await self.request("getFile", {"file_id": file_id})

    async def get_updates(self, offset_id: str | None = None, limit: int = 100):
        """Fetch pending updates using the official getUpdates endpoint."""
        if not 1 <= limit <= 100:
            raise ValueError("limit must be between 1 and 100.")
        payload = {"limit": limit}
        if offset_id is not None:
            payload["offset_id"] = offset_id
        return await self.request("getUpdates", payload)

    async def send_text(self, chat_id: str, text: str, **kwargs):
        """Send a text message. Supports keypad and reply options."""
        payload = {"chat_id": chat_id, "text": text}
        allowed = (
            "metadata",
            "chat_keypad",
            "inline_keypad",
            "reply_to_message_id",
            "disable_notification",
            "chat_keypad_type",
        )
        payload.update(
            {key: value for key, value in kwargs.items()
             if key in allowed and value is not None}
        )
        return await self.request("sendMessage", payload)

    async def send_message(self, chat_id: str, text: str, **kwargs):
        """Alias for send_text."""
        return await self.send_text(chat_id, text, **kwargs)

    async def send_poll(self, chat_id: str, question: str, options: list[str]):
        """Send a poll using the documented sendPoll parameters."""
        if not isinstance(options, list) or len(options) < 2:
            raise ValueError("A poll needs at least two options.")
        return await self.request(
            "sendPoll",
            {"chat_id": chat_id, "question": question, "options": options},
        )

    async def send_quiz(self, *args, **kwargs):
        """Quiz mode is not documented by the current official Bot API."""
        raise NotImplementedError(
            "The current official Rubika Bot API documents sendPoll, not quiz mode."
        )

    async def forward_message(
        self,
        from_chat_id: str,
        message_id: str,
        to_chat_id: str,
        disable_notification: bool = False,
    ):
        """Forward a message to another chat."""
        return await self.request(
            "forwardMessage",
            {
                "from_chat_id": from_chat_id,
                "message_id": message_id,
                "to_chat_id": to_chat_id,
                "disable_notification": disable_notification,
            },
        )

    async def edit_message_text(self, chat_id: str, message_id: str, text: str):
        """Edit a message previously sent by the bot."""
        return await self.request(
            "editMessageText",
            {"chat_id": chat_id, "message_id": message_id, "text": text},
        )

    async def delete_message(self, chat_id: str, message_id: str):
        """Delete a message using deleteMessage."""
        return await self.request(
            "deleteMessage", {"chat_id": chat_id, "message_id": message_id}
        )

    async def ban_chat_member(self, chat_id: str, user_id: str):
        """Ban a user from a group or channel."""
        return await self.request(
            "banChatMember", {"chat_id": chat_id, "user_id": user_id}
        )

    async def unban_chat_member(self, chat_id: str, user_id: str):
        """Unban a user from a group or channel."""
        return await self.request(
            "unbanChatMember", {"chat_id": chat_id, "user_id": user_id}
        )

    def _upload_sync(self, upload_url: str, file: str | bytes, file_name: str):
        content = Path(file).read_bytes() if isinstance(file, (str, Path)) else file
        if not isinstance(content, bytes):
            raise TypeError("file must be a file path or bytes.")
        boundary = "----IRubix" + secrets.token_hex(12)
        mime = mimetypes.guess_type(file_name)[0] or "application/octet-stream"
        header = (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="file"; filename="{file_name}"\r\n'
            f"Content-Type: {mime}\r\n\r\n"
        ).encode("utf-8")
        body = header + content + f"\r\n--{boundary}--\r\n".encode("ascii")
        request = urllib.request.Request(
            upload_url,
            data=body,
            headers={
                "Content-Type": f"multipart/form-data; boundary={boundary}",
                "User-Agent": f"IRubix/{self.__version__}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=max(self.timeout, 180)) as response:
                result = json.loads(response.read().decode("utf-8"))
        except Exception as exc:
            raise RubikaAPIError(f"File upload failed: {exc}") from exc

        data = result.get("data") or result
        file_id = data.get("file_id") if isinstance(data, dict) else None
        if not file_id:
            raise RubikaAPIError("Rubika did not return a file_id after upload.")
        return file_id

    async def send_file(
        self,
        chat_id: str,
        path: str | Path | bytes,
        text: str | None = None,
        file_type: str = "File",
        **kwargs,
    ):
        """Upload a file, then send it with sendFile."""
        name = kwargs.pop("file_name", None)
        if not name:
            name = Path(path).name if isinstance(path, (str, Path)) else "upload.bin"
        upload_result = await self.request("requestSendFile", {"type": file_type})
        upload_data = upload_result.get("data") or upload_result
        upload_url = upload_data.get("upload_url") if isinstance(upload_data, dict) else None
        if not upload_url:
            raise RubikaAPIError("Rubika did not return an upload_url.")
        file_id = await asyncio.to_thread(
            self._upload_sync, upload_url, path, str(name)
        )
        payload = {"chat_id": chat_id, "file_id": file_id}
        if text is not None:
            payload["text"] = text
        allowed = (
            "reply_to_message_id",
            "disable_notification",
            "chat_keypad",
            "inline_keypad",
            "chat_keypad_type",
        )
        payload.update(
            {key: value for key, value in kwargs.items()
             if key in allowed and value is not None}
        )
        return await self.request("sendFile", payload)


    async def upload_file(self, path, file_type: str = "File", *, file_name: str | None = None):
        """Upload a file and return its Rubika file_id without sending it."""
        allowed = {"File", "Image", "Voice", "Video", "Music", "Gif"}
        if file_type not in allowed:
            raise ValueError(f"file_type must be one of: {', '.join(sorted(allowed))}")
        name = file_name or (Path(path).name if isinstance(path, (str, Path)) else "upload.bin")
        result = await self.request_send_file(file_type)
        data = result.get("data") or result
        upload_url = data.get("upload_url") if isinstance(data, dict) else None
        if not upload_url:
            raise RubikaAPIError("Rubika did not return an upload_url.")
        return await asyncio.to_thread(self._upload_sync, upload_url, path, str(name))

    async def download_file(self, file_id: str) -> bytes:
        """Download a file and return raw bytes."""
        result = await self.get_file(file_id)
        data = result.get("data") or result
        url = data.get("download_url") or data.get("file_url") or data.get("url")
        if not url:
            raise RubikaAPIError("Rubika did not return a downloadable file URL.")
        def fetch():
            request = urllib.request.Request(url, headers={"User-Agent": f"IRubix/{self.__version__}"})
            try:
                with urllib.request.urlopen(request, timeout=max(self.timeout, 60)) as response:
                    return response.read()
            except Exception as exc:
                raise RubikaAPIError(f"File download failed: {exc}") from exc
        return await asyncio.to_thread(fetch)

    async def send_image(self, chat_id: str, path, text: str | None = None, **kwargs):
        return await self.send_file(chat_id, path, text=text, file_type="Image", **kwargs)

    async def send_video(self, chat_id: str, path, text: str | None = None, **kwargs):
        return await self.send_file(chat_id, path, text=text, file_type="Video", **kwargs)

    async def send_voice(self, chat_id: str, path, text: str | None = None, **kwargs):
        return await self.send_file(chat_id, path, text=text, file_type="Voice", **kwargs)

    async def send_music(self, chat_id: str, path, text: str | None = None, **kwargs):
        return await self.send_file(chat_id, path, text=text, file_type="Music", **kwargs)

    async def send_gif(self, chat_id: str, path, text: str | None = None, **kwargs):
        return await self.send_file(chat_id, path, text=text, file_type="Gif", **kwargs)

    async def get_chat_info(self, chat_id: str):
        """Alias for get_chat."""
        return await self.get_chat(chat_id)

    async def edit_message(self, chat_id: str, message_id: str, text: str):
        """Alias for edit_message_text."""
        return await self.edit_message_text(chat_id, message_id, text)

    async def register_all_endpoints(self, base_url: str):
        """Register all five Rubika webhook endpoint types."""
        base = base_url.rstrip("/")
        if not base.startswith("https://"):
            raise ValueError("Webhook base URL must use HTTPS.")
        routes = {"ReceiveUpdate":"update", "ReceiveInlineMessage":"inline",
                  "ReceiveQuery":"query", "GetSelectionItem":"selection",
                  "SearchSelectionItems":"search-selection"}
        results = {}
        for endpoint_type, suffix in routes.items():
            results[endpoint_type] = await self.update_bot_endpoints(
                f"{base}/{suffix}", endpoint_type)
        return results

    def middleware(self, middleware):
        """Register middleware(bot, event, next_handler)."""
        if not callable(middleware):
            raise TypeError("middleware must be callable.")
        self._middlewares.append(middleware)
        return middleware

    def add_plugin(self, plugin):
        """Register a plugin exposing setup(bot), or a setup callable."""
        setup = getattr(plugin, "setup", plugin)
        if not callable(setup):
            raise TypeError("Plugin must be callable or expose setup(bot).")
        result = setup(self)
        self._plugins.append(plugin)
        return result

    def load_plugin(self, module_path: str):
        """Import and register a plugin module by dotted path."""
        import importlib
        return self.add_plugin(importlib.import_module(module_path))

    def disconnect(self):
        """Alias for stop()."""
        self.stop()

    async def on_query(self, payload: dict):
        """Process a receiveQuery webhook payload."""
        return await self.process_webhook(payload)

    async def on_selection(self, payload: dict):
        """Process a selection webhook payload."""
        return await self.process_webhook(payload)

    def command(self, names):
        """Register one or more slash commands."""
        commands = [names] if isinstance(names, str) else list(names)
        commands = [str(item).lstrip("/") for item in commands]

        def decorator(function):
            self._handlers.append(("command", commands, function))
            return function
        return decorator

    def message(self, flt=None):
        """Register a message handler. An optional callable filters events."""
        def decorator(function):
            self._handlers.append(("message", flt, function))
            return function
        return decorator

    def callback(self):
        """Register an inline-keyboard callback handler."""
        def decorator(function):
            self._handlers.append(("callback", None, function))
            return function
        return decorator

    async def process_update(self, payload: dict):
        """Process a Rubika receiveUpdate or receiveInlineMessage webhook body."""
        if not isinstance(payload, dict):
            raise TypeError("Webhook payload must be a dictionary.")
        if isinstance(payload.get("update"), dict):
            payload = payload["update"]
        elif isinstance(payload.get("inline_message"), dict):
            payload = {**payload["inline_message"], "type": "InlineMessage"}
        await self._dispatch(payload)

    async def process_webhook(self, payload: dict):
        """Alias for process_update, intended for HTTPS webhook handlers."""
        return await self.process_update(payload)

    async def _dispatch(self, raw: dict):
        # Normalize the two webhook envelopes as well as bare getUpdates objects.
        if isinstance(raw.get("update"), dict):
            raw = raw["update"]
        elif isinstance(raw.get("inline_message"), dict):
            raw = {**raw["inline_message"], "type": "InlineMessage"}
        event = Event(self, raw)
        for kind, value, handler in tuple(self._handlers):
            if kind == "command":
                first = (
                    event.text.strip().split(maxsplit=1)[0].lstrip("/")
                    if event.text.strip() else ""
                )
                if first not in value:
                    continue
            elif kind == "callback":
                if not (
                    "button_id" in raw
                    or "data" in raw
                    or event.type == "InlineMessage"
                ):
                    continue
            elif kind == "message":
                if not event.text and not event.message:
                    continue
                if callable(value) and not value(event):
                    continue

            async def invoke(index=0):
                if index >= len(self._middlewares):
                    result = handler(self, event)
                    if hasattr(result, "__await__"):
                        return await result
                    return result
                middleware = self._middlewares[index]
                async def next_handler():
                    return await invoke(index + 1)
                result = middleware(self, event, next_handler)
                if hasattr(result, "__await__"):
                    return await result
                return result
            try:
                await invoke()
            except Exception as exc:
                print(_terminal_color(f"[IRubix] Handler error: {exc}", _RED), flush=True)

    async def start(self, poll_interval: float = 1.0, limit: int = 100):
        """Start long-running getUpdates polling."""
        if poll_interval < 0.1:
            raise ValueError("poll_interval must be at least 0.1 seconds.")
        if not 1 <= limit <= 100:
            raise ValueError("limit must be between 1 and 100.")
        # Keep the Rubika update cursor between process restarts. Without this,
        # getUpdates starts from the beginning and replays already handled updates.
        state_dir = Path.home() / ".irubix" / "updates"
        token_key = hashlib.sha256(self.token.encode("utf-8")).hexdigest()
        state_file = state_dir / f"{token_key}.json"
        offset = None
        try:
            saved = json.loads(state_file.read_text(encoding="utf-8"))
            if isinstance(saved, dict):
                offset = saved.get("offset_id")
        except (OSError, ValueError, TypeError):
            pass
        # Every fresh process start establishes a clean polling boundary.
        # Updates accumulated while the bot process was stopped are discarded;
        # only updates arriving after polling has started are dispatched.
        initialize_cursor = True

        def save_offset(value):
            if value is None:
                return
            try:
                state_dir.mkdir(parents=True, exist_ok=True)
                temporary = state_file.with_suffix(".tmp")
                temporary.write_text(
                    json.dumps({"offset_id": value}),
                    encoding="utf-8",
                )
                temporary.replace(state_file)
            except OSError:
                # Polling should continue even if the device cannot persist state.
                pass

        self._running = True
        print(_terminal_color("[IRubix] Bot started.", _BOLD + _GREEN), flush=True)
        while self._running:
            payload = {"limit": limit}
            if offset is not None:
                payload["offset_id"] = offset
            try:
                result = await self.request("getUpdates", payload)
                data = result.get("data") or result
                if not isinstance(data, dict):
                    await asyncio.sleep(poll_interval)
                    continue
                next_offset = data.get("next_offset_id")
                updates = data.get("updates") or []
                if initialize_cursor:
                    # Skip updates already waiting when this process first
                    # starts; only updates arriving after this cursor are new.
                    if next_offset is not None:
                        initialize_cursor = False
                else:
                    for update in updates:
                        if isinstance(update, dict):
                            await self._dispatch(update)
                if next_offset is not None:
                    offset = next_offset
                    save_offset(offset)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                print(_terminal_color(f"[IRubix] Polling error: {exc}", _RED), flush=True)
                await asyncio.sleep(2)
            await asyncio.sleep(poll_interval)
        print(_terminal_color("[IRubix] Bot stopped.", _CYAN), flush=True)

    def stop(self):
        """Ask the polling loop to stop."""
        self._running = False

    def run(self, poll_interval: float = 1.0, limit: int = 100):
        """Run polling; inside an active event loop, await the returned coroutine."""
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            try:
                asyncio.run(self.start(poll_interval, limit))
            except KeyboardInterrupt:
                self.stop()
            return None
        return self.start(poll_interval, limit)


Bot = IRubix
