"""PyPI update notifications for IRubix, with Android-friendly TLS handling."""
from __future__ import annotations

import json
import os
import re
import ssl
import sys
import threading
from urllib.error import URLError
from urllib.request import Request, urlopen

_PYPI_JSON = "https://pypi.org/pypi/irubix/json"
_PYPI_PROJECT = "https://pypi.org/project/irubix/"
_TIMEOUT = 8.0

_CYAN = "\033[96m"
_GREEN = "\033[92m"
_RED = "\033[91m"
_YELLOW = "\033[93m"
_MAGENTA = "\033[95m"
_BOLD = "\033[1m"
_RESET = "\033[0m"


def _color(text: str, color: str) -> str:
    if os.environ.get("NO_COLOR") is not None or os.environ.get("TERM", "").lower() == "dumb":
        return text
    return f"{color}{text}{_RESET}"


def _version_key(version: str) -> tuple[int, ...]:
    parts = tuple(int(part) for part in re.findall(r"\d+", str(version)))
    return parts or (0,)


def _is_newer(latest: str, installed: str) -> bool:
    return _version_key(latest) > _version_key(installed)


def _read_json(context=None) -> dict:
    request = Request(
        _PYPI_JSON,
        headers={"Accept": "application/json", "User-Agent": "IRubix-update-check"},
    )
    with urlopen(request, timeout=_TIMEOUT, context=context) as response:
        payload = json.loads(response.read().decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Invalid response from PyPI")
    return payload


def _latest_pypi_version() -> str:
    try:
        payload = _read_json()
    except (URLError, ssl.SSLError, OSError):
        # Some Android Python distributions do not configure a usable CA
        # bundle. Use certifi when installed; never disable TLS verification.
        try:
            import certifi
        except ImportError:
            raise
        payload = _read_json(ssl.create_default_context(cafile=certifi.where()))

    info = payload.get("info")
    version = info.get("version") if isinstance(info, dict) else None
    if not isinstance(version, str) or not version.strip():
        raise ValueError("Could not read IRubix version from PyPI")
    return version.strip()


def _check(installed: str) -> None:
    try:
        latest = _latest_pypi_version()
        if _is_newer(latest, installed):
            version_url = f"{_PYPI_PROJECT}{latest}/"
            lines = [
                "",
                _color("[IRubix] A new version is available!", _BOLD + _CYAN),
                _color(f"Current version: {installed}", _YELLOW),
                _color(f"Latest version: {latest}", _GREEN),
                "",
                _color("PyPI release:", _MAGENTA),
                _color(version_url, _BOLD),
                "",
                _color("To update, run:", _MAGENTA),
                _color("python -m pip install --upgrade irubix", _BOLD),
                "",
            ]
            print("\n".join(lines), file=sys.stderr, flush=True)
        elif _version_key(latest) == _version_key(installed):
            print(_color(f"[IRubix] You are using the latest version ({installed}).", _GREEN), flush=True)
    except Exception as exc:
        print(
            _color(f"[IRubix] Update check failed: {type(exc).__name__}: {exc}", _RED),
            file=sys.stderr,
            flush=True,
        )


def check_for_updates(installed_version: str) -> None:
    """Check PyPI during import and finish before client token prompts."""
    if os.environ.get("IRUBIX_DISABLE_UPDATE_CHECK", "").lower() in {
        "1", "true", "yes", "on"
    }:
        return
    thread = threading.Thread(
        target=_check,
        args=(installed_version,),
        name="irubix-update-check",
        daemon=True,
    )
    thread.start()
    # Keep startup bounded, but ensure the result appears before bot.run()
    # or a hidden token prompt can take over the terminal.
    thread.join(timeout=_TIMEOUT + 2)
