"""Tests for IRubix version comparison and PyPI update notices."""
import io
import json
import unittest
from contextlib import redirect_stderr
from unittest.mock import patch

from irubix._update import _check, _is_newer, _latest_pypi_version


class _FakeResponse:
    def __init__(self, content):
        self.content = content

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def read(self):
        return self.content.encode("utf-8")


def _pypi_payload(version):
    return json.dumps({"info": {"name": "irubix", "version": version}})


class UpdateCheckTests(unittest.TestCase):
    def test_detects_new_patch(self):
        self.assertTrue(_is_newer("0.8.2", "0.8.1"))

    def test_compares_numeric_parts(self):
        self.assertTrue(_is_newer("0.10.0", "0.9.9"))

    def test_same_version_is_not_newer(self):
        self.assertFalse(_is_newer("0.8.1", "0.8.1"))

    def test_older_version_is_not_newer(self):
        self.assertFalse(_is_newer("0.8.0", "0.8.1"))

    @patch("irubix._update.urlopen")
    def test_reads_version_from_pypi_json(self, mock_urlopen):
        mock_urlopen.return_value = _FakeResponse(_pypi_payload("0.12.4"))
        self.assertEqual(_latest_pypi_version(), "0.12.4")

    @patch("irubix._update.urlopen")
    def test_prints_pypi_notice_for_update(self, mock_urlopen):
        mock_urlopen.return_value = _FakeResponse(_pypi_payload("0.12.4"))
        output = io.StringIO()
        with redirect_stderr(output):
            _check("0.12.3")
        message = output.getvalue()
        self.assertIn("[IRubix] A new version is available!", message)
        self.assertIn("Current version: 0.12.3", message)
        self.assertIn("Latest version: 0.12.4", message)
        self.assertIn("https://pypi.org/project/irubix/0.12.4/", message)
        self.assertIn("python -m pip install --upgrade irubix", message)
        self.assertNotIn("github.com/adminVIPZEXNET/irubix/archive", message)

    @patch("irubix._update.urlopen")
    def test_no_notice_when_already_up_to_date(self, mock_urlopen):
        mock_urlopen.return_value = _FakeResponse(_pypi_payload("0.12.4"))
        output = io.StringIO()
        with redirect_stderr(output):
            _check("0.12.4")
        self.assertEqual(output.getvalue(), "")


if __name__ == "__main__":
    unittest.main()
