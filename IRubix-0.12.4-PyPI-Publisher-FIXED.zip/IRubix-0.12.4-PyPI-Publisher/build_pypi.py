#!/usr/bin/env python3
"""Build and publish IRubix to PyPI from Pydroid 3 / Android."""
from pathlib import Path
import getpass
import importlib.metadata as md
import os
import shutil
import subprocess
import sys
import tarfile
import traceback
import zipfile
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = None
DIST = None

# Twine/pkginfo versions with modern Core Metadata support (Python 3.13).
PACKAGES = [
    "twine==6.1.0", "pkginfo==1.12.1", "keyring==25.6.0", "id==1.5.0",
    "readme-renderer==43.0", "requests-toolbelt==1.0.0",
    "importlib-metadata==8.7.0", "rfc3986==2.0.0", "rich==14.1.0",
    "jaraco.context==6.1.2", "jaraco.classes==3.4.0",
    "jaraco.functools==4.6.0", "more-itertools==11.2.1",
    "SecretStorage>=3.3.3", "jeepney>=0.8.0",
]


def is_irubix_project(path):
    path = Path(path)
    if not (path / "setup.py").is_file() or not (path / "irubix" / "__init__.py").is_file():
        return False
    try:
        content = (path / "setup.py").read_text(encoding="utf-8", errors="ignore").lower()
        return 'name="irubix"' in content or "name='irubix'" in content
    except OSError:
        return False


def discover_project():
    candidates = []
    for base in (Path(__file__).resolve().parent, Path.cwd()):
        candidates.extend([base, *base.parents])
    for raw in (
        os.environ.get("IRUBIX_PROJECT_DIR", ""),
        "/storage/emulated/0/Download",
        "/sdcard/Download",
        "/storage/emulated/0/Documents",
        "/storage/emulated/0",
    ):
        if raw:
            candidates.append(Path(raw))
    seen = set()
    for candidate in candidates:
        try:
            candidate = candidate.expanduser().resolve()
        except Exception:
            continue
        if candidate in seen:
            continue
        seen.add(candidate)
        if is_irubix_project(candidate):
            return candidate
    roots = [Path("/storage/emulated/0/Download"), Path("/sdcard/Download"), Path("/storage/emulated/0")]
    visited = set()
    for search_root in roots:
        if not search_root.is_dir():
            continue
        for current, dirs, files in os.walk(str(search_root)):
            try:
                depth = len(Path(current).relative_to(search_root).parts)
            except Exception:
                depth = 99
            dirs[:] = [d for d in dirs if d not in {
                "Android", ".thumbnails", "cache", "Caches", ".git", "node_modules",
                "__pycache__", "Pictures", "Movies", "Music", "DCIM"
            }]
            if depth >= 6:
                dirs[:] = []
            marker = os.path.realpath(current)
            if marker in visited:
                dirs[:] = []
                continue
            visited.add(marker)
            if "setup.py" in files and is_irubix_project(current):
                return Path(current)
    return None


def run(args, env=None, check=True):
    cmd = [sys.executable, *map(str, args)]
    print("\n>", " ".join(cmd), flush=True)
    return subprocess.run(cmd, cwd=str(ROOT), env=env or os.environ.copy(), check=check)


def installed(name, wanted=None):
    try:
        got = md.version(name)
        return wanted is None or got == wanted
    except md.PackageNotFoundError:
        return False


def ensure_publish_stack():
    print("\nChecking PyPI publishing dependencies...", flush=True)
    needs = []
    for spec in PACKAGES:
        name, _, version = spec.partition("==")
        if not installed(name, version if version else None):
            needs.append(spec)
    if needs:
        print("Installing publishing packages:", ", ".join(needs), flush=True)
        # Install the pinned core first. Dependencies are explicit for Pydroid.
        run(["-m", "pip", "install", "--no-cache-dir", "--no-deps", *needs])
    required = ["twine", "pkginfo", "keyring", "readme-renderer",
                "requests-toolbelt", "importlib-metadata", "rfc3986", "rich",
                "jaraco.context", "jaraco.classes", "jaraco.functools",
                "more-itertools", "SecretStorage", "jeepney", "id"]
    missing = [name for name in required if not installed(name)]
    if missing:
        raise RuntimeError("Publishing dependencies still missing: " + ", ".join(missing))
    versions = "Twine " + md.version("twine") + " / pkginfo " + md.version("pkginfo")
    print(versions, flush=True)
    run(["-c", "import twine, keyring, pkginfo, requests_toolbelt; print('Twine imports OK')"])


def validate_artifacts(artifacts):
    """Check embedded metadata and return the exact package version."""
    found_versions = set()
    for artifact in artifacts:
        metadata = None
        if artifact.name.endswith(".whl"):
            with zipfile.ZipFile(artifact) as archive:
                names = [n for n in archive.namelist() if n.endswith(".dist-info/METADATA")]
                if len(names) != 1:
                    raise RuntimeError(f"{artifact.name}: expected one .dist-info/METADATA, found {len(names)}")
                metadata = archive.read(names[0]).decode("utf-8", "replace")
        elif artifact.name.endswith(".tar.gz"):
            with tarfile.open(artifact, "r:gz") as archive:
                members = [m for m in archive.getmembers() if m.name.endswith("/PKG-INFO")]
                if not members:
                    raise RuntimeError(f"{artifact.name}: PKG-INFO is missing")
                f = archive.extractfile(members[0])
                metadata = f.read().decode("utf-8", "replace") if f else ""
        fields = {}
        for line in metadata.splitlines():
            if not line.strip():
                break
            if ": " in line:
                key, value = line.split(": ", 1)
                fields[key.lower()] = value.strip()
        if not fields.get("name") or not fields.get("version"):
            raise RuntimeError(
                f"{artifact.name}: embedded package metadata is invalid "
                f"(Name={fields.get('name')!r}, Version={fields.get('version')!r}). "
                "No upload was attempted."
            )
        if fields["name"].lower().replace("_", "-") != "irubix":
            raise RuntimeError(f"Unexpected package name in {artifact.name}: {fields['name']!r}")
        found_versions.add(fields["version"])
        print(f"Metadata OK: {artifact.name} | {fields['name']} {fields['version']}", flush=True)
    if len(found_versions) != 1:
        raise RuntimeError("Wheel and source archive contain different package versions.")
    return found_versions.pop()


def check_pypi_release_available(version):
    """Stop before upload when this exact release already exists on PyPI."""
    url = f"https://pypi.org/pypi/irubix/{version}/json"
    request = Request(url, headers={"Accept": "application/json", "User-Agent": "IRubix-PyPI-publisher"})
    try:
        with urlopen(request, timeout=8) as response:
            if getattr(response, "status", 200) == 200:
                raise RuntimeError(
                    f"Version {version} already exists on PyPI. PyPI does not allow replacing release files. "
                    f"Increase the version in setup.py and irubix/__init__.py, rebuild, then publish.\n"
                    f"Existing release: {url}"
                )
    except HTTPError as exc:
        if exc.code == 404:
            print(f"PyPI preflight OK: version {version} is not published yet.", flush=True)
            return
        raise RuntimeError(f"PyPI preflight failed with HTTP {exc.code}: {url}") from exc
    except URLError as exc:
        print(f"WARNING: Could not pre-check PyPI release ({exc}). Continuing; PyPI may reject an existing version.", flush=True)
        return


def find_artifacts():
    files = sorted(p for p in DIST.glob("*") if p.is_file() and
                   (p.name.endswith(".whl") or p.name.endswith(".tar.gz")))
    if not any(p.name.endswith(".whl") for p in files) or not any(p.name.endswith(".tar.gz") for p in files):
        return []
    return files


def main():
    global ROOT, DIST
    print("IRubix complete Pydroid 3 builder + PyPI publisher", flush=True)
    ROOT = discover_project()
    if ROOT is None:
        print("\nAutomatic search failed. Enter the folder containing setup.py.", flush=True)
        raw = input("IRubix project path: ").strip().strip('"').strip("'")
        ROOT = Path(raw).expanduser().resolve() if raw else None
    if ROOT is None or not is_irubix_project(ROOT):
        raise RuntimeError("IRubix project not found. Select irubix-main (contains setup.py and irubix/__init__.py).")
    DIST = ROOT / "dist"
    print("Project found:", ROOT, flush=True)

    # Fail early if the source files do not agree on the release version.
    import re
    setup_text = (ROOT / "setup.py").read_text(encoding="utf-8")
    init_text = (ROOT / "irubix" / "__init__.py").read_text(encoding="utf-8")
    setup_match = re.search(r"version\s*=\s*[\"']([^\"']+)[\"']", setup_text)
    init_match = re.search(r"^__version__\s*=\s*[\"']([^\"']+)[\"']", init_text, re.MULTILINE)
    if not setup_match or not init_match or setup_match.group(1) != init_match.group(1):
        raise RuntimeError("Version mismatch: setup.py and irubix/__init__.py must declare the same version.")
    print("Source version:", setup_match.group(1), flush=True)

    if not installed("build"):
        run(["-m", "pip", "install", "--no-cache-dir", "build"])

    # Never reuse stale or partially-created distributions from an earlier run.
    for path in (DIST, ROOT / "build", ROOT / "irubix.egg-info"):
        if path.exists():
            shutil.rmtree(path) if path.is_dir() else path.unlink()

    print("\nBuilding fresh wheel and source archive...", flush=True)
    run(["-m", "build", "--no-isolation"])
    artifacts = find_artifacts()
    if len(artifacts) != 2:
        raise RuntimeError("Build did not produce exactly one wheel and one .tar.gz source archive.")
    package_version = validate_artifacts(artifacts)
    check_pypi_release_available(package_version)

    ensure_publish_stack()
    # Validate core distribution metadata ourselves above. Do not invoke
    # `twine check` on Android: readme-renderer imports the optional native
    # `nh3` sanitizer, which often has no compatible Pydroid wheel. The upload
    # command does not need that README-rendering path.
    print("Twine check skipped (Android/Pydroid nh3 compatibility). Core metadata validated.", flush=True)
    run(["-c", "from id import AmbientCredentialError; from twine.commands.upload import main; print('Twine upload command OK')"])

    try:
        token = getpass.getpass("\nPyPI API token (input is hidden): ").strip()
    except Exception:
        token = input("PyPI API token: ").strip()
    if not token:
        raise RuntimeError("No token entered; upload cancelled.")

    env = os.environ.copy()
    env.update({
        "TWINE_USERNAME": "__token__",
        "TWINE_PASSWORD": token,
        "TWINE_NON_INTERACTIVE": "1",
        "TWINE_REPOSITORY_URL": "https://upload.pypi.org/legacy/",
        "PYTHON_KEYRING_BACKEND": "keyring.backends.null.Keyring",
    })
    print("\nUploading validated distributions to PyPI...", flush=True)
    run(["-m", "twine", "upload", "--non-interactive", *map(str, artifacts)], env=env)
    print("\nPyPI upload command completed successfully.", flush=True)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nCancelled by user.", flush=True)
    except Exception as exc:
        print("\nERROR:", exc, flush=True)
        traceback.print_exc()
    try:
        input("\nPress Enter to close...")
    except EOFError:
        pass
