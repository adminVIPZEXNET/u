#!/usr/bin/env python3
"""Robust IRubix 0.12.4 Pydroid 3 / PyPI launcher."""
from pathlib import Path
import os
import runpy
import sys

REQUIRED = ("setup.py", "irubix/__init__.py", "build_pypi.py")

def valid_project(folder):
    folder = Path(folder)
    return folder.is_dir() and all((folder / item).is_file() for item in REQUIRED)

def candidates_from(start):
    start = Path(start).expanduser().resolve()
    # Check the opened file's folder and nearby extraction/nesting layouts.
    seen = set()
    queue = [(start, 0)]
    while queue:
        folder, depth = queue.pop(0)
        try:
            folder = folder.resolve()
        except Exception:
            continue
        if folder in seen:
            continue
        seen.add(folder)
        if valid_project(folder):
            yield folder
        if depth < 4 and folder.is_dir():
            try:
                children = sorted(folder.iterdir(), key=lambda p: p.name.lower())
            except OSError:
                children = []
            for child in children:
                if child.is_dir() and child.name not in {
                    "__pycache__", ".git", "build", "dist", ".venv", "venv"
                }:
                    queue.append((child, depth + 1))
        if depth == 0 and folder.parent != folder:
            queue.append((folder.parent, 1))

def main():
    script = Path(__file__).resolve()
    project = next(candidates_from(script.parent), None)

    if project is None:
        print("IRubix 0.12.4 publisher: automatic folder detection failed.")
        print("The launcher file is:", script)
        print("This usually means the ZIP was not fully extracted.")
        print("Extract ALL files, then run this launcher from the extracted folder.")
        print("Required files: setup.py, irubix/__init__.py, build_pypi.py")
        typed = input("Enter the extracted IRubix project folder path (or Enter to cancel): ").strip().strip('"').strip("'")
        if not typed:
            print("Cancelled: project files were not found; no build or upload was attempted.")
            return
        project = Path(typed).expanduser().resolve()
        if not valid_project(project):
            print("ERROR: That folder still does not contain all required IRubix files.")
            print("No upload was attempted. Check the extraction and try again.")
            return

    os.chdir(project)
    sys.path.insert(0, str(project))
    print("=" * 68)
    print("IRubix 0.12.4 — Pydroid 3 / PyPI Publisher")
    print("Launcher:", script)
    print("PROJECT PATH:", project)
    print("Project files verified: setup.py, irubix/__init__.py, build_pypi.py")
    print("The publisher will use this exact folder, not the old 0.12.2 project.")
    print("=" * 68, flush=True)
    runpy.run_path(str(project / "build_pypi.py"), run_name="__main__")

if __name__ == "__main__":
    main()
